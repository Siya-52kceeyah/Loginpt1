package com.mycompany.mavenchatapp;

// Import required libraries
import javax.swing.JOptionPane;      // For GUI dialog boxes
import java.io.FileWriter;           // For file writing operations
import java.io.IOException;          // For IO exception handling
import java.util.Scanner;           // For user input scanning
import org.json.JSONObject;         // For JSON data Storing

/**
 * Main application class that serves as the entry point for the chat application.
 * Coordinates between the login system and chat functionality.
 */
public class MavenChatapp {
    /**
     * Main method - application entry point 
     * @param args
     */
    public static void main(String[] args) {
        // Create login instance and attempt login
        Login login = new Login();
        if (login.loginUser()) {
            // If login successful, start chat application
            QuickChatApplication chatApp = new QuickChatApplication();
            chatApp.runApplication();
        }
    }
}

/**
 * Handles user authentication including registration and login.
 * This class Validates username, password and phone number formats.
 */
class Login {
    // User credentials storage
    private String username;
    private String password;
    private String cellPhoneNumber;
    private boolean isRegistered = false;
    private final Scanner scanner = new Scanner(System.in);

    /** Authenticates user through console input
     * if true login successful, false otherwise
     */
    public boolean loginUser() {
        // Check if user needs to register first
        if (!isRegistered) {
            registerUser();
        }
        
        // Prompt for login credentials
        System.out.println("\nLogin");
        System.out.print("Enter your username to login: ");
        String inputUsername = scanner.nextLine();
        System.out.print("Enter your password to login: ");
        String inputPassword = scanner.nextLine();
               
        // Validate credentials
        boolean success = inputUsername.equals(username) && inputPassword.equals(password);
        if (success) {
            JOptionPane.showMessageDialog(null, "Welcome " + username + ", it is great to see you again.");
        } else {
            JOptionPane.showMessageDialog(null, "Username or password incorrect, please try again.");
        }
        return success;
    }

    /**
     * Guides user through registration process with input validation
     */
    public void registerUser() {
        // Validate username format (must contain underscore and be 5 chars)
        while (true) {
            username = JOptionPane.showInputDialog("Enter your username (must contain underscore and be equal to 5 characters):");
            if (checkUserName()) break;
            JOptionPane.showMessageDialog(null, 
                "Username is not correctly formatted, please ensure that your username contains an underscore and is no more than 5 characters in length.",
                "Invalid Username", JOptionPane.ERROR_MESSAGE);
        }

        // Validate password strength (8 chars with capital, number, special char)
        while (true) {
            password = JOptionPane.showInputDialog("Enter your password (must be equal to 8 characters, with capital, number, and special character):");
            if (checkPassword()) break;
            JOptionPane.showMessageDialog(null, 
                "Password is not correctly formatted, please ensure that the password contains at least 8 characters, a capital letter, a number and a special character.",
                "Invalid Password", JOptionPane.ERROR_MESSAGE);
        }

        // Validate South African phone number format (+27XXXXXXXX)
        while (true) {
            cellPhoneNumber = JOptionPane.showInputDialog("Enter your cell phone number (+27 format):");
            if (checkCellPhoneNumber()) break;
            JOptionPane.showMessageDialog(null, 
                "Cellphone number is not correctly formatted, please ensure it has +27 followed by 8 digits.",
                "Invalid Cellphone", JOptionPane.ERROR_MESSAGE);
        }
        
        // Mark registration as complete
        isRegistered = true;
    }

    /**
     * Validates username format requirements
     * if true username contains underscore and is ≤5 characters
     */
    private boolean checkUserName() {
        return username != null && username.contains("_") && username.length() <= 5;
    }

    /**
     * Validates password strength requirements
     * if true password has 8+ chars with capital, number and special char
     */
    private boolean checkPassword() {
        if (password == null || password.length() < 8) return false;
        // Check for at least one capital letter
        boolean hasCapital = !password.equals(password.toLowerCase());
        // Check for at least one digit
        boolean hasNumber = password.matches(".*\\d.*");
        // Check for at least one special character
        boolean hasSpecial = !password.matches("[A-Za-z0-9 ]*");
        return hasCapital && hasNumber && hasSpecial;
    }

    /**
     * Validates South African phone number formats
     * if true phone number matches either local (0XXXXXXXXX) or 
     *         international (+27XXXXXXXX) format
     */
    private boolean checkCellPhoneNumber() {
        if (cellPhoneNumber == null) return false;
        // Remove any formatting characters
        String cleanedNumber = cellPhoneNumber.replaceAll("[\\s-]", "");
        // Check valid formats
        return cleanedNumber.matches("^(0\\d{9})$") || cleanedNumber.matches("^(\\+?27\\d{8,9})$");
    }
}

/**
 * Main chat application class that handles message sending and viewing functionality.
 * Provides menu interface and coordinates message operations.
 */
class QuickChatApplication {
    private static int totalMessagesSent = 0;  // Tracks total messages sent in session
    
    /**
     * Main application loop displaying menu and handling user choices
     */
    public void runApplication() {
        JOptionPane.showMessageDialog(null, "Welcome to QuickChat");
        
        // Main application loop
        while (true) {
            // Display menu options
            String choice = JOptionPane.showInputDialog(
                "Choose an option:\n" +
                "1) Send Messages\n" +
                "2) Show recently sent messages\n" +
                "3) Quit"
            );
            
            // Exit condition
            if (choice == null || choice.equals("3")) break;
            
            // Process user choice using enhanced switch
            switch (choice) {
                case "1" -> sendMessages();
                case "2" -> JOptionPane.showMessageDialog(null, "Coming Soon.");
                default -> JOptionPane.showMessageDialog(null, "Invalid choice. Please try again.");
            }
        }
    }
    
    /**
     * Handles sending multiple messages based on user input
     */
    private void sendMessages() {
        try {
            // Get number of messages to send
            int messageCount = Integer.parseInt(JOptionPane.showInputDialog(
                "How many messages would you like to send?"
            ));
            
            // Process each message
            for (int i = 0; i < messageCount; i++) {
                Message message = createMessage();
                if (message != null) {
                    totalMessagesSent++;
                    // Show message details
                    JOptionPane.showMessageDialog(null, message.getMessageDetails());
                }
            }
            
            // Display total messages sent
            JOptionPane.showMessageDialog(null, "Total messages sent: " + totalMessagesSent);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Please enter a valid number.");
        }
    }
    
    /**
     * Creates a new message by collecting recipient and content from user
     * Message object if created successfully, null otherwise
     */
    private Message createMessage() {
        // Get recipient number
        String recipient = JOptionPane.showInputDialog("Enter recipient's phone number (with international code):");
        // Get message content
        String text = JOptionPane.showInputDialog("Enter your message (max 250 characters):");
        
        // Validate message length
        if (text.length() > 250) {
            JOptionPane.showMessageDialog(null, "Please enter a message of less than 250 characters.");
            return null;
        }
        
        // Create and process message
        Message message = new Message(recipient, text);
        String result = message.processMessage();
        JOptionPane.showMessageDialog(null, result);
        // Return message only if it was sent (not stored or disregarded)
        return result.contains("sent") ? message : null;
    }
}

/**
 * Represents a single chat message with validation, processing and storage capabilities.
 * Handles message ID generation, recipient validation, and message hashing.
 */
class Message {
    private final String messageId;          // Unique 10-digit message identifier
    private final String recipient;         // Recipient's phone number
    private final String messageText;       // Message content
    private static int messageCounter = 0;  // Global message counter

    /**
     * Constructor - creates new message with auto-generated ID
     * @param recipient Phone number of message recipient
     * @param messageText Content of the message
     */
    public Message(String recipient, String messageText) {
        this.messageId = generateMessageId();
        this.recipient = recipient;
        this.messageText = messageText;
        messageCounter++;  // Increment global counter
    }

    /**
     * Generates random 10-digit message ID
     * String representation of the ID (between 1000000000-9999999999)
     */
    private String generateMessageId() {
        long id = (long) (Math.random() * 9000000000L) + 1000000000L;
        return String.valueOf(id);
    }

    /**
     * Validates message ID format
     * @return true if ID is valid (10 digits)
     */
    public boolean checkMessageID() {
        return messageId != null && messageId.length() == 10 && messageId.matches("\\d+");
    }

    /**
     * Validates recipient phone number format
     * -1 if invalid length, 0 if missing international code, 1 if valid
     */
    public int checkRecipientCell() {
        if (recipient == null || recipient.isEmpty()) return -1;
        // Clean number by removing non-digit characters except +
        String cleanNumber = recipient.replaceAll("[^+0-12]", "");
        if (cleanNumber.length() > 10) return -1;
        if (!cleanNumber.startsWith("+") && !cleanNumber.startsWith("0")) return 0;
        return 1;
    }

    /**
     * Creates unique message hash for identification
     * Format: first 2 digits of ID:counter-FIRSTWORDLASTWORD
     * @return Formatted hash string in uppercase
     */
    public String createMessageHash() {
        // Extract first and last words from message
        String[] words = messageText.split("\\s+");
        String firstWord = words.length > 0 ? words[0] : "";
        String lastWord = words.length > 1 ? words[words.length - 1] : firstWord;
        return (messageId.substring(0, 2) + ":" + messageCounter + "-" + firstWord + lastWord).toUpperCase();
    }

    /**
     * Processes message through validation and user choices
     * @return Status message indicating action taken
     */
    public String processMessage() {
        // Validate message ID
        if (!checkMessageID()) return "Invalid message ID";
        
        // Validate recipient number
        int recipientCheck = checkRecipientCell();
        if (recipientCheck == -1) return "Recipient number is too long";
        if (recipientCheck == 0) return "Recipient number must include international code";
        
        // Present user with action options
        String[] options = {"Send Message", "Disregard Message", "Store Message"};
        int choice = JOptionPane.showOptionDialog(null, 
            "What would you like to do with this message?", 
            "Message Options", 
            JOptionPane.DEFAULT_OPTION, 
            JOptionPane.QUESTION_MESSAGE, 
            null, 
            options, 
            options[0]);
        
        // Process user choice using enhanced switch
        return switch (choice) {
            case 0 -> sentMessage();
            case 1 -> "Message disregarded";
            case 2 -> { 
                storeMessage(); 
                yield "Message stored";
            }
            default -> "No action taken";
        };
    }

    /** Confirmation message for sent messages
     */
    public String sentMessage() {
        return "Message sent to " + recipient;
    }

    /**
     * Formatted string with all message details for display
     */
    public String getMessageDetails() {
        return """
               Message ID: %s
               Message Hash: %s
               Recipient: %s
               Message: %s
               """.formatted(messageId, createMessageHash(), recipient, messageText);
    }

    /**
     * @return Total count of messages created
     */
    public static int getMessageCounter() {
        return messageCounter;
    }

    /**
     * Store message data in JSON format to file
     */
    public void storeMessage() {
        try {
            // Create JSON object with message data
            JSONObject messageJson = new JSONObject();
            messageJson.put("messageID", messageId);
            messageJson.put("recipient", recipient);
            messageJson.put("messageText", messageText);
            messageJson.put("hash", createMessageHash());
            
            // Append to storage file
            try (FileWriter file = new FileWriter("stored_messages.json", true)) {
                file.write(messageJson + "\n");
                file.flush();
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error storing message: " + e.getMessage());
        }
    }

    // Standard getter methods
    public String getMessageId() { return messageId; }
    public String getRecipient() { return recipient; }
    public String getMessageText() { return messageText; }
}

